package com.sina.util.dnscache.cache;

import java.util.ArrayList;

import com.sina.util.dnscache.model.DomainModel;
import com.sina.util.dnscache.model.HttpDnsPack;
import com.sina.util.dnscache.model.IpModel;

/**
 * Created by fenglei on 15/4/21.
 */
public interface IDnsCache {

    /**
     * 获取 domain 缓存
     * @param sp
     * @param domain
     * @return
     */
    public DomainModel getDnsCache( String sp, String domain ) ;


    /**
     * 插入一条缓存记录
     * @param dnsPack
     * @return
     */
    public DomainModel insertDnsCache(HttpDnsPack dnsPack) ;

    /**
     * 设置测速后信息
     * @param ipModel
     */
    public IpModel setSpeedInfo(IpModel ipModel) ;


    /**
     * 获取即将过期的domain信息
     * @return
     */
    public ArrayList<DomainModel> getExpireDnsCache() ;


    /**
     * 清除数据
     */
    public void clear();


    /**
     * 打印 domain 表
     */
    public void printf_domain();


    /**
     * 打印 ip 表
     */
    public void printf_ip() ;


}
