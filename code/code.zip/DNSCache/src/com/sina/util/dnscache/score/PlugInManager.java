package com.sina.util.dnscache.score;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import android.util.Log;

import com.sina.util.dnscache.model.IpModel;
import com.sina.util.dnscache.score.plugin.ErrNumPlugin;
import com.sina.util.dnscache.score.plugin.PriorityPlugin;
import com.sina.util.dnscache.score.plugin.SpeedTestPlugin;
import com.sina.util.dnscache.score.plugin.SuccessNumPlugin;
import com.sina.util.dnscache.score.plugin.SuccessTimePlugin;

public class PlugInManager {

	public ArrayList<IPlugIn> plugIn = new ArrayList<IPlugIn>() ;
	
	public PlugInManager(){
		
		plugIn.add( new SpeedTestPlugin( 40  ) ) ; //速度插件
		plugIn.add( new PriorityPlugin( 30  ) ) ; //优先级推荐插件
		plugIn.add( new SuccessNumPlugin( 10  ) ) ; //历史成功次数插件
		plugIn.add( new ErrNumPlugin( 10  ) ) ; //历史错误次数插件
		plugIn.add( new SuccessTimePlugin( 10  ) ) ; //历史最后成功访问时间插件
	}
	
	
	public void run( ArrayList<IpModel> list ){

		for( IpModel temp : list ) temp.grade = 0 ; 
		
		for( IPlugIn plug : plugIn ) plug.run( list );
		
		ipModelSort( list );
	}
	
	public void ipModelSort(ArrayList<IpModel> list){
		
		Collections.sort(list, new IpModelSort());

		for( IpModel temp : list ){
			Log.d("TAG","ip = " + temp.ip + "  grade = " + temp.grade);
		}
	}
	
	class IpModelSort implements Comparator<IpModel> {
		@Override
		public int compare(IpModel lhs, IpModel rhs) {
			return lhs.grade > rhs.grade ? -1 : 1 ;
		}
	}
}

