/**
 * 
 */
package com.sina.util.dnscache.cache;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 *
 * 项目名称: DNSCache
 * 类名称: MemoryCache
 * 类描述: 
 * 创建人: fenglei
 * 创建时间: 2015-3-26 下午3:58:00
 * 
 * 修改人:
 * 修改时间: 
 * 修改备注:
 * 
 * @version V1.0
 */
public class MemoryCache<K, V> extends LinkedHashMap<K, V> {


	/**
	 * 序列化版本ID
	 */
	private static final long serialVersionUID = -5612721046751678048L;

	/**
     * 缓存初始容量大小
     */
    private static int initSize = 8;

    /**
     * 缓存容量，默认为initSize
     */
    private int capacity = initSize;


    /**扩容因子，当容量达最大值时扩容的百分比。经官方测试，0.75为时间和空间的最优值*/
    /**
     * 注：本缓存器实现了固定容量缓存，当容量超出指定容量的最大值时，缓存器会根据LRU策略将超出的缓存删掉，不会再进行扩容
     */
    private static final float DEFAULT_LOAD_FACTOR = 0.75f;

    /**
     * 资源锁
     */
    private Object lock = new Object();

    /**
     * 创建一个Cache对象
     *
     * @param capacity cache的容量，capacity必须大于0，否则将使用默认值
     */
    public MemoryCache(int capacity) {
        super(initSize, DEFAULT_LOAD_FACTOR, true);

        //如果传入的capacity为大于初始容量值，则更新容量值
        if (capacity > initSize) {
            this.capacity = capacity;
        }
    }

    /**
     * 创建一个Cache对象
     *
     * @param initSize 初始容量大小
     * @param capacity cache的容量，capacity必须大于0，否则将使用默认值
     */
    public MemoryCache(int initSize, int capacity) {
        super(initSize, DEFAULT_LOAD_FACTOR, true);

        //如果传入的capacity为大于初始容量值，则更新容量值
        if (capacity > initSize) {
            this.capacity = capacity;
        }
    }

    ///////////////////////////////////////////////

    @Override
    public V get(Object key) {

        synchronized (lock) {
            return super.get(key);
        }
    }

    @Override
    public V put(K key, V value) {
        synchronized (lock) {
            return super.put(key, value);
        }
    }

    @Override
    public void putAll(Map<? extends K, ? extends V> map) {
        synchronized (lock) {

            super.putAll(map);
        }
    }

    @Override
    public V remove(Object key) {
        synchronized (lock) {
            return super.remove(key);
        }
    }

    @Override
    public void clear() {
        synchronized (lock) {
            super.clear();
        }
    }

    @Override
    public boolean containsKey(Object key) {
        synchronized (lock) {
            return super.containsKey(key);
        }
    }

    @Override
    public int size() {

        synchronized (lock) {
            return super.size();
        }
    }

    @Override
    protected boolean removeEldestEntry(Entry<K, V> eldest) {
        return size() > capacity;
    }

    //////////////////////////////////////////////////

    public int getCapcity() {

        return capacity;
    }

}
