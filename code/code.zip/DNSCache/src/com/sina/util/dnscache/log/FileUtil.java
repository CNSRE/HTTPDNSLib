package com.sina.util.dnscache.log;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import android.os.Environment;
import android.os.StatFs;

/**
 * 文件操作工具类
 * 
 * @author xingyu10
 *
 */
public class FileUtil {

    /**
     * 判断SD卡是否还有可用空间，小于10M为不可用
     * 
     * @return
     */
    public static boolean haveFreeSpaceInSD() {
        if (Environment.getExternalStorageState().equals(android.os.Environment.MEDIA_MOUNTED)) {
            StatFs st = new StatFs(Environment.getExternalStorageDirectory().getPath());
            int blockSize = st.getBlockSize();
            long available = st.getAvailableBlocks();
            long availableSize = (blockSize * available);
            if (availableSize < 1024 * 1024 * 10) {// //sd卡空间如果小于10M，就认为sd卡空间不足
                return false;
            }
            return true;
        }
        return false;
    }

    /**
     * 获取SD卡的路径
     * 
     * @return
     */
    public static String getSDPath() {
        return Environment.getExternalStorageDirectory().getPath();
    }

    /**
     * 写文件内容，一次只写一行
     * 
     * @param file 目标文件
     * @param append 是否追加
     * @param line 一行字符串
     */
    public static void writeFileLine(File file, boolean append, String line) {
        FileWriter writer = null;
        try {
            writer = new FileWriter(file, append);
            String lineSeparator = System.getProperty("line.separator");
            writer.write(line + lineSeparator);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (null != writer) {
                try {
                    writer.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
