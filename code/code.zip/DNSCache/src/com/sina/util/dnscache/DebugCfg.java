package com.sina.util.dnscache;

/**
 * Created by fenglei on 15/4/21.
 */
public class DebugCfg {

    /**
     * 调试 开关
     */
    public static boolean DEBUG = false ;

}
