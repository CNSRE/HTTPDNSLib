/**
 * 
 */
package com.sina.util.dnscache.model;


/**
 *
 * 项目名称: DNSCache <br>
 * 类名称: IpModel <br>
 * 类描述: ip数据模型 - 对应ip表 <br>
 * 创建人: fenglei <br>
 * 创建时间: 2015-3-26 下午5:23:06 <br>
 * 
 * 修改人:  <br>
 * 修改时间:  <br>
 * 修改备注:  <br>
 * 
 * @version V1.0
 */
public class IpModel {
	
	public IpModel(){}
	
	/**
	 * 自增id <br>
	 * 
	 * 该字段映射类 {@link com.sina.util.dnscache.cache.DBConstants } IP_COLUMN_ID 字段 <br>
	 */
	public long id = -1 ; 
	
	/**
	 * domain id 关联id
	 * 
	 * 该字段映射类 {@link com.sina.util.dnscache.cache.DBConstants } IP_COLUMN_DOMAIN_ID 字段 <br>
	 */
	public int d_id = -1 ; 
	
	/**
	 * 服务器ip地址
	 * 
	 * 该字段映射类 {@link com.sina.util.dnscache.cache.DBConstants } IP_COLUMN_PORT 字段 <br>
	 */
	public String ip = "" ;
	
	/**
	 * ip服务器对应的端口
	 * 
	 * 该字段映射类 {@link com.sina.util.dnscache.cache.DBConstants } IP_COLUMN_PORT 字段 <br>
	 */
	public int port = -1 ; 
	
	/**
	 * ip服务器对应的sp运营商
	 * 
	 * 该字段映射类 {@link com.sina.util.dnscache.cache.DBConstants } IP_COLUMN_SP 字段 <br>
	 */
	public String sp = "" ; 
	
	/**
	 * ip过期时间
	 * 
	 * 该字段映射类 {@link com.sina.util.dnscache.cache.DBConstants } IP_COLUMN_TTL 字段 <br>
	 */
	public String ttl = "0" ; 
	
	/**
	 * ip服务器优先级-排序算法策略使用
	 * 
	 * 该字段映射类 {@link com.sina.util.dnscache.cache.DBConstants } IP_COLUMN_PRIORITY 字段 <br>
	 */
	public String priority = "0" ; 
	
	/**
	 * 最后测速下行速度值
	 * 
	 * 该字段映射类 {@link com.sina.util.dnscache.cache.DBConstants } IP_COLUMN_FINALLY_SPEED 字段 <br>
	 */
	public String finally_speed = "0" ; 
	
	/**
	 * ip服务器链接产生的成功数
	 * 
	 * 该字段映射类 {@link com.sina.util.dnscache.cache.DBConstants } IP_COLUMN_SUCCESS_NUM 字段 <br>
	 */
	public String success_num = "0" ; 
	
	/**
	 * ip服务器链接产生的错误数
	 * 
	 * 该字段映射类 {@link com.sina.util.dnscache.cache.DBConstants } IP_COLUMN_ERR_NUM 字段 <br>
	 */
	public String err_num = "0" ; 
	
	/**
	 * ip服务器最后成功链接时间
	 * 
	 * 该字段映射类 {@link com.sina.util.dnscache.cache.DBConstants } IP_COLUMN_FINALLY_SUCCESS_TIME 字段 <br>
	 */
	public String finally_success_time = "0" ; 


	
	/**
	 * 评估体系 评分分值
	 */
	public float grade = 0 ; 
	

    public String toString(){

        String str = "IpModel Data \n" ;

        str += "-- id = " + id + "\n" ;
        str += "-- ip = " + ip + "\n" ;
        str += "-- d_id = " + d_id + "\n" ;
        str += "-- port = " + port + "\n" ;
        str += "-- sp = " + sp + "\n" ;
        str += "-- ttl = " + ttl + "\n" ;
        str += "-- priority = " + priority + "\n" ;
        str += "-- finally_speed = " + finally_speed + "\n" ;
        str += "-- success_num = " + success_num + "\n" ;
        str += "-- err_num = " + err_num + "\n" ;
        str += "-- finally_success_time = " + finally_success_time + "\n" ;
        str += "-- grade = " + grade + "\n" ;
        str += "\n" ;

        return str ;
    }

}
