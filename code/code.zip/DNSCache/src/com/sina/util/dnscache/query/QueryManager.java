package com.sina.util.dnscache.query;

import java.util.ArrayList;

import com.sina.util.dnscache.cache.IDnsCache;
import com.sina.util.dnscache.cache.ServerIpDefaultValue;
import com.sina.util.dnscache.model.DomainModel;
import com.sina.util.dnscache.model.IpModel;

/**
 * Created by fenglei on 15/4/21.
 */
public class QueryManager implements IQuery {

    private IDnsCache dnsCache = null ;

    public QueryManager( IDnsCache dnsCache ){

        this.dnsCache = dnsCache ;
    }

    /**
     * 根据host名字查询server ip
     * @return
     */
    @Override
    public DomainModel queryDomainIp(String sp, String host) {

        //从缓存中查询，如果为空 情况有两种 1：没有缓存数据  2：数据过期
    	DomainModel domainModel = getCacheDomainIp(sp, host) ; 

        //如果从缓存中没有获取到数据，则根据内置数据组装返回对象
        if( domainModel == null || domainModel.ipModelArr == null || domainModel.ipModelArr.size() == 0 ){
            String[] ipList = ServerIpDefaultValue.getServerIp(sp, host) ;
            if( ipList == null ) return null ; // 如果该域名在内置缓存数据中不存在 则返回null
            domainModel = new DomainModel();
            domainModel.domain = host ;
            domainModel.sp = sp ;
            domainModel.ipModelArr = new ArrayList<IpModel>() ;
            for( int i = 0 ; i < ipList.length ; i++ ){
                domainModel.ipModelArr.add(new IpModel()) ;
                domainModel.ipModelArr.get(i).ip = ipList[i] ;
                domainModel.ipModelArr.get(i).sp = sp ;
            }
        }

        return domainModel;
    }
    
    
    /**
     * 从缓存层获取获取数据
     * @param sp
     * @param host
     * @return
     */
    public DomainModel getCacheDomainIp(String sp, String host){
    	return dnsCache.getDnsCache(sp, host) ;
    }
}
