package com.sina.util.dnscache.httpdns;

import android.util.Log;

import com.sina.util.dnscache.httpdns.requests.ApacheHttpClientNetworkRequests;
import com.sina.util.dnscache.httpdns.requests.INetworkRequests;
import com.sina.util.dnscache.model.HttpDnsPack;
import com.sina.util.networktype.NetworkManager;

/**
 * Created by fenglei on 15/4/21.
 */
public class HttpDnsManager implements IHttpDns {

    private INetworkRequests netWork = null ;
    private IJsonParser jsonObj = null ;

    public HttpDnsManager(){

        netWork = new ApacheHttpClientNetworkRequests() ;
        jsonObj = new IJsonParser.JavaJSON_SINAHTTPDNS() ;
    }

    @Override
    public HttpDnsPack requestHttpDns(String domain) {
    	
    	String jsonDataStr = null ;
    	HttpDnsPack dnsPack = null ;
    	
    	if( HttpDnsConstants.isSinaHttpDns ){
	    	try {
	        	// 使用新浪自己的httpdns服务器请求数据
	            Log.d("TAG" , "httpdns 服务器请求开始" ) ;
	            String sina_httpdns_api_url = HttpDnsConstants.HTTPDNS_SERVER_API + domain ;
	            jsonDataStr = netWork.requests( sina_httpdns_api_url ) ;
	            Log.d("TAG" , "HttpDnsPack Requests URL = " + sina_httpdns_api_url ) ;
	            Log.d("TAG" , "HttpDnsPack Requests jsonDataStr = " + jsonDataStr ) ;
	            dnsPack = jsonObj.JsonStrToObj(jsonDataStr) ;
	            Log.d("TAG" , "httpdns 服务器请求成功" ) ;
			} catch (Exception e) {
				// TODO: handle exception
			}
    	}

    	
        // 如果新浪自家的服务器没有拿到数据，或者数据有问题，则使用 dnspod 提供的接口获取数据
        if( dnsPack == null ) {
        	Log.d("TAG" , "启用备用方案，访问dnspod接口开始" ) ;
        	String dnspod_httpdns_api_url = HttpDnsConstants.DNSPOD_SERVER_API + domain ;
        	jsonDataStr = netWork.requests( dnspod_httpdns_api_url ) ;
        	if( jsonDataStr == null || jsonDataStr.equals("") ) return null ; //如果dnspod 也没提取到数据 则返回空
        	dnsPack = new HttpDnsPack();
        	try {
        		String IP_TTL[] = jsonDataStr.split(",");
        		String IPArr[] = IP_TTL[0].split(";") ;
        		String TTL = IP_TTL[1] ;
        		dnsPack.domain = domain ;
        		dnsPack.device_ip = NetworkManager.Util.getLocalIpAddress() ;
        		dnsPack.device_sp = String.valueOf( NetworkManager.getInstance().SP_TYPE ) ; 
        		
        		dnsPack.dns = new HttpDnsPack.IP[IPArr.length]; 
        		for( int i = 0 ; i < IPArr.length ; i++ ){
        			dnsPack.dns[i] = new HttpDnsPack.IP() ;
        			dnsPack.dns[i].ip = IPArr[i];
        			dnsPack.dns[i].ttl = TTL ;
        			dnsPack.dns[i].priority = "0" ;
        		}
			} catch (Exception e) {
				dnsPack = null ; 
			}
        	
        	Log.d("TAG" , "启用备用方案，访问dnspod接口完成" ) ;
        }
        
        // 如果前两个策略都没有拿到数据，就先返回null吧， 后期加上从本地dns获取数据可以 和 直接发送udp包到权威dns服务器获取a记录
        if( dnsPack == null ){
        	
        	return null ; 
        }
        
        // 如果是 wifi 网络 sp  则为 ssid 名字
        if( NetworkManager.getInstance().NETWORK_TYPE == NetworkManager.NETWORK_TYPE_WIFI ){
            dnsPack.localhostSp = NetworkManager.getInstance().SP_TYPE_STR ;
        }else{
            // 如果是 0 就是未知运营商
            dnsPack.localhostSp = dnsPack.device_sp ;
        }
        
        return dnsPack ;
    }

}
