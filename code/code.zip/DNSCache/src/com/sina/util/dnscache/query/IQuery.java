package com.sina.util.dnscache.query;

import com.sina.util.dnscache.model.DomainModel;

/**
 * Created by fenglei on 15/4/21.
 */
public interface IQuery {

    public DomainModel queryDomainIp(String sp, String host) ;

    
    public DomainModel getCacheDomainIp(String sp, String host) ;
}
