package com.sina.util.dnscache.httpdns;

import com.sina.util.dnscache.model.HttpDnsPack;

/**
 * Created by fenglei on 15/4/21.
 */
public interface IHttpDns {

    public HttpDnsPack requestHttpDns(String domain) ;

}
