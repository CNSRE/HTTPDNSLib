package com.sina.util.dnscache;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class MainActivity extends Activity {

    public Button button = null ;
    public EditText editText = null ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        DNSCache.Init(this);


        editText = (EditText)findViewById(R.id.editText) ;
        button = (Button)findViewById(R.id.button) ;
        button.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // 查询 domain 信息
                String api = editText.getText().toString() ;

                Log.d("TAG", "查询开始 http dns") ;
                
                final DomainInfo[] domainInfo = DNSCache.getInstance().getDomainServerIp(api) ;

                for( DomainInfo temp : domainInfo){
                    Log.d("DomainInfo" , "id = " + temp.id ) ;
                    Log.d("DomainInfo" , "host = " + temp.host ) ;
                    Log.d("DomainInfo" , "url = " + temp.url ) ;
                }

                Log.d("TAG", "查询完毕 http dns") ;


                new Thread(new Runnable() {
                    @Override
                    public void run() {

                        // 请求api接口

                        String url = domainInfo[0].url ;
                        String host = domainInfo[0].host ;

                        //////////////////////////////////////////////////////////////////

                        String result = null;
                        BufferedReader reader = null;
                        try {
                            HttpClient client = new DefaultHttpClient();
                            HttpGet request = new HttpGet();
                            request.addHeader("host",host);
                            request.setURI( new URI(url) );
                            HttpResponse response = client.execute(request);

                            reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

                            StringBuffer strBuffer = new StringBuffer("");
                            String line = null;

                            while ((line = reader.readLine()) != null) {
                                strBuffer.append(line);
                            }
                            result = strBuffer.toString();

                            // - - - - - - - - - - - - - - - - - - - - - - - -

                            domainInfo[0].data = result ;
                            domainInfo[0].code = String.valueOf(response.getStatusLine().getStatusCode());

                            // - - - - - - - - - - - - - - - - - - - - - - - -

                        } catch (Exception e) {
                            e.printStackTrace();
                        } finally {
                            if (reader != null) {
                                try {
                                    reader.close();
                                    reader = null;
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }
                        }

                        //////////////////////////////////////////////////////////////////

                        // 请求后结果反馈
                        DNSCache.getInstance().setDomainServerIpInfo( domainInfo[0] );

                        Log.d("TAG", "请求完毕 result = " + domainInfo[0]) ;

                    }
                    
                }).start();

            }
        });
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.textView) {

            DNSCache.getInstance().getDnsCacheManager().clear();

            return true;
        }else if (id == R.id.action_printf_domain) {

            DNSCache.getInstance().getDnsCacheManager().printf_domain();

            return true;
        }else if (id == R.id.action_printf_ip) {

            DNSCache.getInstance().getDnsCacheManager().printf_ip();

            return true;
        }else if (id == R.id.action_settings) {

            return true;
        }
        

        return super.onOptionsItemSelected(item);
    }
}
