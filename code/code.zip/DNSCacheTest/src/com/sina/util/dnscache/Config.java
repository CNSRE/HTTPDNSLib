package com.sina.util.dnscache;

import java.util.ArrayList;

public class Config {
	
    public static final int DEFCONCURRENCYNUM = 3 ; 
    
    public static final int DEFREQUESTSNUM = 10 ; 
	/**
	 * 配置的url列表文件路径
	 */
	public static String urlFilePath = "" ; 
	
	/**
	 * 配置的线程池并发线程数
	 */
	public static int concurrencyNum = DEFCONCURRENCYNUM ; 
	
	/**
	 * 配置的总请求数量
	 */
	public static int requestsNum = DEFREQUESTSNUM ;
	
	
	/**
	 * 文本文件中的Url
	 */
	public static ArrayList<String> fileUrlList = null ; 
	
}
