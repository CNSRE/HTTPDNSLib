package com.sina.util.dnscache;

import java.util.ArrayList;
import java.util.concurrent.Callable;

import android.os.Handler;
import android.os.Message;



public class TaskManager {

	/////////////////////////////////////////////////////////////////
	
	private static TaskManager Instance = null;

    private TaskManager() { }

    public static TaskManager getInstance() {

        if( Instance == null ){
            Instance = new TaskManager();
        }
        return Instance;
    }
    
	/////////////////////////////////////////////////////////////////

    public ArrayList<TaskModel> list = null;
    
    public ThreadPool threadPool = null ; 
    
	/////////////////////////////////////////////////////////////////

    
    int finishTag = 0;
    public void startTask(final Handler handler ){
        finishTag = 0;
    	threadPool = new ThreadPool(SpfConfig.getInstance().getInt(R.id.config_threadpool_num+"", Config.DEFCONCURRENCYNUM)) ; 
    	for( final TaskModel temp : list ){
    		
        	Callable<TaskModel> call = new Callable<TaskModel>() {
    			@Override
    			public TaskModel call() throws Exception {
    				Message message = new Message();
                    message.what = 1;
                    message.obj = temp;
                    handler.sendMessage(message);
                    
                    finishTag ++;
                    if (finishTag >= list.size()) {
                        message = new Message();
                        message.what = 3;
                        handler.sendMessage(message);
                    }
    				return temp;
    			}
    		};
    		
    		threadPool.runTask(temp, call);
    		
    		try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
    	}
    	
    	
//    	monitorThread = new Thread(new Runnable() {
//			public void run() {
//				boolean isRun = false;
//				do{
//					isRun = threadPool.fixedThreadPool.isShutdown() ; 
//					try {
//						Thread.sleep(100);
//					} catch (InterruptedException e) {
//						e.printStackTrace();
//					}
//					Log.d("TAG", "isRun = " + isRun) ;
//				}while( isRun);
//				Message message = new Message();
//                message.what = 3;
//                handler.sendMessage(message);
//			}
//		});
//    	monitorThread.start();
    	
    }

    public void stopTask( ){
    	
    	if(threadPool != null)
    		threadPool.fixedThreadPool.shutdownNow();
    }
    
    
	/////////////////////////////////////////////////////////////////

    public void initData(  ArrayList<String> dataList  ){
    	
    	list = new ArrayList<TaskModel>() ;
    	for( int i = 0 ; i < SpfConfig.getInstance().getInt(R.id.config_request_num+"", Config.DEFREQUESTSNUM) ; i++ ){
    		TaskModel modelTemp = new TaskModel() ;
    		modelTemp.url = dataList.get( (int) (Math.random() * ( dataList.size() - 1 )) ) ;
    		list.add( modelTemp ) ;
    	}
    	
    }
    
    public void clear(){
    	
    	list = null ; 
    }
    
	/////////////////////////////////////////////////////////////////

    
    
    
	
}
