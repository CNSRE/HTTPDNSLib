package com.sina.util.dnscache;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.ViewFlipper;

import com.sina.util.dnscache.util.HttpDnsRecordUtil;
import com.sina.util.dnscache.util.ToastUtil;

@SuppressLint("HandlerLeak")
public class DNSCacheTestActivity extends Activity {

    public Button switchBtn = null;
    public boolean isSwitchBtn = false;

    public Button clearBtn = null;

    public ListView listView = null;
    public TaskModelAdapter taskAdapter = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        DNSCache.Init(this);

        Config.fileUrlList = FileTools.getFromAssets(this, "url_2.txt");

        switchBtn = (Button) findViewById(R.id.switchBtn);
        mViewFlipper = (ViewFlipper) findViewById(R.id.main_flipper_view);
        switchBtn.setOnClickListener(new Button.OnClickListener() {// 创建监听
                    public void onClick(View v) {
                        mViewFlipper.setDisplayedChild(0);
                        isSwitchBtn = !isSwitchBtn;
                        switchBtn.setText(isSwitchBtn == false ? "模拟开始" : "模拟停止");
                        if (isSwitchBtn) {

                            taskAdapter.initDtaa();
                            taskAdapter.notifyDataSetChanged();

                            new Thread(new Runnable() {
								
								@Override
								public void run() {
									// TODO Auto-generated method stub
		                            TaskManager.getInstance().clear();
		                            TaskManager.getInstance().initData(Config.fileUrlList);
		                            TaskManager.getInstance().startTask(handler);
								}
							}).start();

                        } else {
                            TaskManager.getInstance().stopTask();
                        }
                    }
                });

        clearBtn = (Button) findViewById(R.id.clearBtn);
        clearBtn.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                mViewFlipper.setDisplayedChild(0);
                Message message = new Message();
                message.what = 2;
                handler.sendMessage(message);
                TaskManager.getInstance().stopTask();
                TaskManager.getInstance().clear();
                HttpDnsRecordUtil.removeFiles();
                ThreadPool.ID_NUMBER = 0;
                ToastUtil.showText(getBaseContext(), "数据清理完毕");
//                switchBtn.performClick();
            }
        });

        taskAdapter = new TaskModelAdapter(this);
        listView = (ListView) findViewById(R.id.listView);
        listView.setAdapter(taskAdapter);
        listView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int index, long arg3) {

                TaskModel taskModel = taskAdapter.list.get(index);
                TaskInfoActivity.InitData(taskModel);
                Intent intent = new Intent();
                intent.setClass(DNSCacheTestActivity.this, TaskInfoActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
        findViewById(R.id.main_config_btn).setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                mViewFlipper.setDisplayedChild(1);
            }
        });

        findViewById(R.id.main_stat_btn).setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                mViewFlipper.setDisplayedChild(2);
                refreshStatView();
            }

            private void refreshStatView() {
                new Thread() {
                    public void run() {
                        List<TaskModel> data = new ArrayList<TaskModel>();
                        int succ = 0;
                        long totaldomainExpendTime = 0;
                        long totalhostExpendTime = 0;
                        File[] files = HttpDnsRecordUtil.getRecordFiles();
                        if (null == files) {
                            updateUI(0, 0, 0);
                            return ;
                        }
                        for (File recordFile : files) {
                            try {
                                BufferedReader br = new BufferedReader(new FileReader(recordFile));
                                String line = null;
                                while ((line = br.readLine()) != null) {
                                    JSONObject jsonObject = new JSONObject(line);
                                    TaskModel model = new TaskModel();
                                    model.domainExpendTime = jsonObject.optLong("domainExpendTime");
                                    model.hostExpendTime = jsonObject.optLong("hostExpendTime");
                                    if (model.domainExpendTime > model.hostExpendTime) {
                                        succ++;
                                    }
                                    totaldomainExpendTime += model.domainExpendTime;
                                    totalhostExpendTime += model.hostExpendTime;
                                    data.add(model);
                                }
                                br.close();
                            } catch (FileNotFoundException e) {
                                e.printStackTrace();
                            } catch (IOException e) {
                                e.printStackTrace();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        updateUI(data.size(), succ, totaldomainExpendTime - totalhostExpendTime);
                    }

                    private void updateUI(final int totalTask, final int succ, final long totalOptimizeTime) {
                        new Handler(Looper.getMainLooper()).post(new Runnable() {

                            @Override
                            public void run() {
                                TextView statInfo = (TextView) mViewFlipper.findViewById(R.id.stat_info);
                                if (totalTask > 0) {
                                    statInfo.setText("总任务数为：" + totalTask + "\n降低延迟次数为：" + succ + "\n延迟次数为：" + (totalTask - succ) + "\n"
                                            + "平均延迟降低时间为：" + (totalOptimizeTime / totalTask) + "ms");
                                } else {
                                    statInfo.setText("无测试数据");
                                }
                            }
                        });

                    };
                }.start();
            }
        });
        bindViewEvent();
    }

    private void bindViewEvent() {
        final EditText etThreadpoolNum = (EditText) mViewFlipper.findViewById(R.id.config_threadpool_num);
        final EditText etRequestNum = (EditText) mViewFlipper.findViewById(R.id.config_request_num);
        int threadpoolNum = SpfConfig.getInstance().getInt(R.id.config_threadpool_num + "", Config.concurrencyNum);
        int requestNum = SpfConfig.getInstance().getInt(R.id.config_request_num + "", Config.requestsNum);
        etThreadpoolNum.setText(threadpoolNum + "");
        etRequestNum.setText(requestNum + "");
        mViewFlipper.findViewById(R.id.config_reset).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                etThreadpoolNum.setText(Config.DEFCONCURRENCYNUM + "");
                etRequestNum.setText(Config.DEFREQUESTSNUM + "");

                SpfConfig.getInstance().putInt(R.id.config_threadpool_num + "", Config.DEFCONCURRENCYNUM);
                SpfConfig.getInstance().putInt(R.id.config_request_num + "", Config.DEFREQUESTSNUM);
                ToastUtil.showText(getBaseContext(), "已经恢复默认");
            }
        });
        mViewFlipper.findViewById(R.id.config_confirm).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                SpfConfig.getInstance().putInt(R.id.config_threadpool_num + "", Integer.valueOf(etThreadpoolNum.getText().toString()));
                SpfConfig.getInstance().putInt(R.id.config_request_num + "", Integer.valueOf(etRequestNum.getText().toString()));
                ToastUtil.showText(getBaseContext(), "设置完成");
            }
        });
    }

    public final Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
            case 1:
                TaskModel taskModel = (TaskModel) msg.obj;
                taskAdapter.list.add(taskModel);
//                HttpDnsRecordUtil.record(taskModel);
                break;
            case 2:
                taskAdapter.initDtaa();
                break;
            case 3:
                isSwitchBtn = !isSwitchBtn;
                switchBtn.setText(isSwitchBtn == false ? "模拟开始" : "模拟停止");
                Collections.sort(taskAdapter.list, comparator);
                for (TaskModel model : taskAdapter.list) {
                    HttpDnsRecordUtil.record(model);
                }
                ToastUtil.showText(getBaseContext(), "任务全部完成");
                break;
            }
            taskAdapter.notifyDataSetChanged();
        }
    };

    Comparator<TaskModel> comparator = new Comparator<TaskModel>() {
        public int compare(TaskModel s1, TaskModel s2) {
            return (int) (s1.taskID - s2.taskID);
        }
    };
    private ViewFlipper mViewFlipper;

}