package com.sina.util.dnscache;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class TaskInfoActivity extends Activity{

	public ImageButton leftBtn = null ;
	
	
	public TextView taskID = null ; 
	public TextView status = null ; 
	public TextView taskStartTime = null ; 
	public TextView taskStopTime = null ; 
	public TextView taskExpendTime = null ; 
	
	public TextView httpDnsResult = null ; 
	public TextView httpDnsExpendTime = null ; 
	
	public TextView hostUrl = null ; 
	public TextView hostIp = null ; 
	public TextView hostCode = null ; 
	public TextView hostResult = null ; 
	public TextView hostExpendTime = null ; 
	
	public TextView domainUrl = null ; 
	public TextView domainIp = null ; 
	public TextView domainCode = null ; 
	public TextView domainResult = null ; 
	public TextView domainExpendTime = null ; 
	
	public TextView netType = null ; 
	public TextView spName = null ; 
	
	
	public static TaskModel taskModel = null ;
	public static void InitData(TaskModel taskModel){
		TaskInfoActivity.taskModel = taskModel ;
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_task_info);
		
		leftBtn = (ImageButton)findViewById(R.id.left) ;
		leftBtn.setOnClickListener( new ImageButton.OnClickListener(){
			public void onClick(View v) {
				finish();
			}
		} );
		
		//////////////////////////////////////////////////////////////
		
		taskID = (TextView)findViewById( R.id.taskID ) ;
		status = (TextView)findViewById( R.id.status ) ;
		taskStartTime = (TextView)findViewById( R.id.taskStartTime ) ;
		taskStopTime = (TextView)findViewById( R.id.taskStopTime ) ;
		taskExpendTime = (TextView)findViewById( R.id.taskExpendTime ) ;
		
		httpDnsResult = (TextView)findViewById( R.id.httpDnsResult ) ;
		httpDnsExpendTime = (TextView)findViewById( R.id.httpDnsExpendTime ) ;
		
		hostUrl = (TextView)findViewById( R.id.hostUrl ) ;
		hostIp = (TextView)findViewById( R.id.hostIp ) ;
		hostCode = (TextView)findViewById( R.id.hostCode ) ;
		hostResult = (TextView)findViewById( R.id.hostResult ) ;
		hostExpendTime = (TextView)findViewById( R.id.hostExpendTime ) ;
		
		domainUrl = (TextView)findViewById( R.id.domainUrl ) ;
		domainIp = (TextView)findViewById( R.id.domainIp ) ;
		domainCode = (TextView)findViewById( R.id.domainCode ) ;
		domainResult = (TextView)findViewById( R.id.domainResult ) ;
		domainExpendTime = (TextView)findViewById( R.id.domainExpendTime ) ;
		
		netType = (TextView)findViewById( R.id.netType ) ;
		spName = (TextView)findViewById( R.id.spName ) ;
		
		//////////////////////////////////////////////////////////////
		
		taskID.setText( String.valueOf( "ID: " + taskModel.taskID ) );
		status.setText( String.valueOf( "状态: " + ( taskModel.status == 1 ? "成功" :  "失败" ) ) );
		taskStartTime.setText( String.valueOf( "开始时间: " + Tools.getStringDateShort(taskModel.taskStartTime) ) );
		taskStopTime.setText( String.valueOf( "结束时间: " + Tools.getStringDateShort(taskModel.taskStopTime) ) );
		taskExpendTime.setText( String.valueOf( "消耗时间: " + taskModel.taskExpendTime + "毫秒") );

		httpDnsResult.setText( String.valueOf( "返回结果: " + taskModel.httpDnsResult ) );
		httpDnsExpendTime.setText( String.valueOf( "响应时间: " + taskModel.httpDnsExpendTime + "毫秒" ) );
		
		hostUrl.setText( String.valueOf( "访问URL: " + taskModel.hostUrl ) );
		hostIp.setText( String.valueOf( "访问服务器IP: " + taskModel.hostIp ) );
		hostCode.setText( String.valueOf( "服务器返回CODE: " + taskModel.hostCode ) );
		hostResult.setText( String.valueOf( "服务器返回结果: " + taskModel.hostResult ) );
		hostExpendTime.setText( String.valueOf( "请求耗时: " + taskModel.hostExpendTime + "毫秒" ) );
		
		domainUrl.setText( String.valueOf( "访问URL: " + taskModel.domainUrl ) );
		domainIp.setText( String.valueOf( "访问服务器IP: " + taskModel.domainIp ) );
		domainCode.setText( String.valueOf( "服务器返回CODE: " + taskModel.domainCode ) );
		domainResult.setText( String.valueOf( "服务器返回结果: " + taskModel.domainResult ) );
		domainExpendTime.setText( String.valueOf( "请求耗时: " + taskModel.domainExpendTime + "毫秒" ) );
		
		netType.setText( String.valueOf( "网络环境：" + taskModel.netType ) );
		spName.setText( String.valueOf( "运营商: " + taskModel.spName ) );
		
		
	}
	
}
